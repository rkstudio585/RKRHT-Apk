![Link-X](https://g.top4top.io/p_2253ocnon0.jpg)
<b><p align="center">Hack with Link</p></b>

## Version 2.0 Update:
* Codded Totally From Scratch
* New, Clean Interface
* All Script Files are Python
* Index Folders Shorted
> All Web View Files are used from Same Index files. So, no extra folders for every Attack Method.
* Used *Cloudflared Browser Checking* as Web view Method. Instead of the Old, Weird, **Press To Continue**
* Tunnel Errors Solved
* Excluded using of some Heavy Libraries of Python
* Removed useless, user's problematic Functionality: Custom Web Page

### Attack Methods:
* Camera
* Voice
* Clipboard
* Location
* Paste Jacking
> Not a Hacking method, But worth including
* Device Details
  - Added Some More Grabing Methods
> Grab as much Information as possible from Victim's Device
* Upcoming:
  - Embed Methods (Add Methods Together)

### Tunnel Methods:
* Localhost (For developers)
* Ngrok (5 Trials)
* Cloudflared (Best Usages)

### Methods Overview:
* Camera
> Hack Victim's front Camera and take pictures every (2/3) seconds
* Voice
> Hack Victim's Microphone and Record 5 Seconds audio
* Clipboard
> Hack Victim's Clipboard and Grab last copied Text
* Location
> Hack Victim's Location and Show exact Location
* Paste Jacking
> Not actually a hacking Method. Show a Text, and Copy another Text
* Device Details
> Probably my favorite Attack Method. Grab the much Information as possible from Victim's Device. Including: Screen Info, Battery Info, Connection Info, Country Info etc...

### Installation Commands
```
apt update -y
apt upgrade -y
pkg install python git -y
git clone https://github.com/Toxic-Noob/Link-X
cd Link-X
python setup.py
python link-x.py
```

## Note:
* This tool is only for Educational Purpose
* ToxicNoob Inc. will not be responsible for any Misuse

#### Every Suggestions are Welcomed
* Contact via <a href="mailto:toxicnoob.sl4d3.official@gmail.com">Email</a>

### Tool ScreenShots :
![Link-X Screenshot](https://j.top4top.io/p_2611er4g04.jpg)
![Link-X Screenshot](https://k.top4top.io/p_2611nfsus5.jpg)
![Link-X Screenshot](https://f.top4top.io/p_26110qugx3.jpg)

### Visitors :
![Visitor Count](https://profile-counter.glitch.me/Toxic-Noob/count.svg)
