![ToxicBomber](https://h.top4top.io/p_2611gbau61.jpg)
<p align="center">Most Updated SMS Bomber For Bangladeshi Numbers</p>

## Note:
Due to Python Version changes, ToxicBomber's Version 3.0 Wasn't Working anymore. So We updated ToxicBomber Python Version 3.10 to 3.11. And to be Noted, You Have to reInstall the Tool after removing The old one from your device. To Remove Old Version, simply type:
``` shell script
rm -rf ToxicBomber
```
In your Terminal

### Version 4.1 Updates:
<li>Done Some Mejor Changes of Source Files</li>
<li>Dead APIs Removed</li>
<li>New APIs added</li>
<li>Timer Added</li>
<li>Supports Python 3.11</li>

### Commands :
To remove the old Version:
``` shell script
cd ~
rm -rf ToxicBomber
```
To Install Tool Newly:

``` shell script
apt update -y
apt upgrade -y
pkg install python -y
pkg install git -y
pip install requests
git clone https://github.com/Toxic-Noob/ToxicBomber
cd ToxicBomber
python Tbomb.py
```

## Note:
<li>This Tool Is Only For Educational Purpose</li>
<li>ToxicNoob Will Never Be Responsible For Any Misuse</li>
<li>Use It At Your Own Risk</li>

## Contact :
For Any Help or Suggestions, Contact With Us:
<li> Via <a href="mailto: ToxicNoob.Sl4d3.Official@gmail.com">Email</a>


# Screenshots:
<img src="https://a.top4top.io/p_2556qdsww0.jpg" alt="ToxicBomber ScreenShot">
<img src="https://c.top4top.io/p_2556dzaf30.jpg" alt="ToxicBomber ScreenShot">

### Visitors :

![Visitor Count](https://profile-counter.glitch.me/Toxic-Noob/count.svg)
