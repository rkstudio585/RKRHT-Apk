<?php
include 'ip.php';
header('Location: siteName/index.html');
exit
?>
