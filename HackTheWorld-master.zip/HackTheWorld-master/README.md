# HackTheWorld
An Python Script For Generating Payloads that Bypasses All Antivirus so far .

## Screenshot
![snap1](https://user-images.githubusercontent.com/33988926/36351226-b781c05e-14cc-11e8-8c3d-53bcc68b0ead.png)

![snap2](https://user-images.githubusercontent.com/33988926/36351227-b7bc0624-14cc-11e8-9731-e1eea24ba273.png)

![snap3](https://user-images.githubusercontent.com/33988926/36351228-b7f73b68-14cc-11e8-9723-480fda74ac23.png)

![proofnodist](https://user-images.githubusercontent.com/33988926/36351343-5d716e28-14ce-11e8-96e3-df9e0d007365.png)


# Requirements
- Metasploit Framework
- Wine
- Mingw-w64 Compiler

## ⭕️ Getting Started
1. ```git clone https://github.com/stormshadow07/HackTheWorld.git```
2. ```cd HackTheWorld```
3. ```chmod +x install.sh && ./install.sh```



