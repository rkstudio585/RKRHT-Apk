       _______ __               __
      / ____(_) /   ____  _____/ /_______
     / /   / / /   / __ \/ ___/ //_/ ___/
    / /___/ / /___/ /_/ / /__/ ,< (__  )
    \____/_/_____/\____/\___/_/|_/____/v2.1
    
### CiLocks | Android/IOS Hacking 📱
#### Crack Interface lockscreen, Metasploit and More Android/IOS Hacking
![](https://img.shields.io/github/license/tegal1337/CiLocks)
![](https://img.shields.io/github/issues/tegal1337/CiLocks)
![](https://img.shields.io/github/issues-closed/tegal1337/CiLocks)
[![contributions welcome](https://img.shields.io/badge/contributions-welcome-brightgreen.svg?style=flat)](https://github.com/tegal1337/CiLocks/issues)
![](https://img.shields.io/github/forks/tegal1337/CiLocks)
![](https://img.shields.io/github/stars/tegal1337/CiLocks)
![](https://img.shields.io/github/last-commit/tegal1337/CiLocks)

<img src ="https://img.shields.io/badge/Important-notice-red" />
<h4>Please Don't Use for illegal Activity</h4>

#### Update Available V2.1 🚀 
- [x] Added New Tools 
    - [x] Root Android {Supersu} Not Support All OS Version
    - [x] Jump To Adb Toolkit
        - [x] Shell
        - [x] ScreenShot
        - [x] Copy All Camera Photo
        - [x] Copy All WhatsApp Folder
        - [x] Copy All Data Storage
        - [x] Manual Copy {Costum}
        - [x] Backup Data
        - [x] Restore Data
        - [x] Permissons Reset
        - [x] Reboot
    - [x] Remove Lockscreen {Root}
    - [x] Jump To Metasploit   
        - [x] Install Application
        - [x] Create Payload Backdoor {Msfvenom} Singed
        - [x] Run Metasploit
        - [x] Inject Payload In Original Application
     - [x] Phone Info
     - [x] Control Android {Scrcpy}
- [x] Brute Pin 4 Digit
- [x] Brute Pin 6 Digit
- [x] Brute LockScreen Using Wordlist
- [x] Bypass LockScreen {Antiguard} Not Support All OS Version
- [x] Reset Data
- [x] IP Logger (Track IP Location and Information) 
- [x] SpyCam (Take webcam shots from target just sending a malicious link) 
- [x] IOS Payload
- [x] FireStore Vulnerability

#### Screenshoot 📷

  Screenshoot 01 | Screenshoot 02  | Screenshoot 03 
:-------------------------:|:-------------------------:|:---------------------:
![](https://github.com/tegal1337/CiLocks/blob/main/Screenshoot/cilocks01.png?raw=true)|![](https://github.com/tegal1337/CiLocks/blob/main/Screenshoot/cilocks02.png?raw=true)|![](https://github.com/tegal1337/CiLocks/blob/main/Screenshoot/cilocks03.png?raw=true)

  Screenshoot 04 | Screenshoot 05  | Screenshoot 06 
:-------------------------:|:-------------------------:|:---------------------:
![](https://github.com/tegal1337/CiLocks/blob/main/Screenshoot/cilocks04.png?raw=true)|![](https://github.com/tegal1337/CiLocks/blob/main/Screenshoot/cilocks05.png?raw=true)|![](https://github.com/tegal1337/CiLocks/blob/main/Screenshoot/cilocks06.png?raw=true)

### Requirements
    
    sudo apt update -y
    
    sudo apt install php nodejs npm adb scrcpy wget unzip apktool jq -y

#### And if needed
    
    sudo apt install msfconsole -y 

### Required

    ADB {Android SDK}
    
    USB Cable
    
    Android Emulator {Nethunter/Termux} Root
    
    Or Computer


### Installation For Linux 

    git clone https://github.com/tegal1337/CiLocks
    
    cd CiLocks
    
    chmod +x cilocks
    
    sudo bash cilocks 
    
    or sudo ./cilocks


<!--  After Following All Steps Just Type In Terminal **root@tegalsec:~** **./cilocks** -->
or download <a href="https://github.com/tegal1337/CiLocks/releases/download/V2.1/Cilocks_V2.1.zip">here</a>

### For Android Emulator

    Install Termux/NetHunter

    Install Busybox
    
    Root Access
    
    Otg Cable

#### If brute doesn't work then uncomment this code

    # adb shell input keyevent 26
    
    if 5x the wrong password will automatically delay 30 seconds

#### To use Spycam / Iplogger if the url does not appear

     Register on ngrok.com
     
     Write the command on the path /CiLocks
     # ./ngrok authtoken <TOKEN>

#### Article & Video

- Android Malware https://www.instagram.com/p/CPqJAvHjQ2Q/
- YAFI TECH https://www.youtube.com/watch?v=gYIfJUiBBWo
- Malware Tech https://www.youtube.com/watch?v=ZhBvWkGknKA
- KitPloit https://www.kitploit.com/2021/05/cilocks-android-lockscreen-bypass.html

#### Thanks to original Author of the tools used in CiLocks

#### Contributors

[![contributions](https://img.shields.io/badge/contributions-welcome-brightgreen.svg?style=flat)](https://github.com/tegal1337/CiLocks/issues)
<table>
  <tr>
    <td align="center"><a href="https://dalpan.github.io"><img src="https://avatars.githubusercontent.com/u/33548464?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Van Lyubov</b></sub></a></td>
    <td align="center"><a href="https://lolic0d3.github.io"><img src="https://avatars.githubusercontent.com/u/59540270?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Ali Akbar</b></sub></a></td>
    
  </tr>
</table>

#### Reference 

https://stackoverflow.com/questions/29072501/how-to-unlock-android-phone-through-adb
<br>
http://www.hak5.org/episodes/hak5-1205
<br>
https://github.com/kosborn/p2p-adb
<br>
https://forum.xda-developers.com/t/universal-guide-root-any-android-device-manually.2684210/
<br>
https://stackoverflow.com/questions/14685721/how-can-i-do-factory-reset-using-adb-in-android
<br>
https://github.com/Screetsec/TheFatRat
<br>

#### Follow Us

Instagram: https://www.instagram.com/tegalsec/
<br>Facebook: https://www.facebook.com/tegal1337/
<br>Github : https://github.com/tegal1337/
<br>Website : https://tegalsec.org/


[![Foo](https://www.paypalobjects.com/en_US/i/btn/btn_donate_LG.gif)](#)
#### Support our organization by giving donations
  Bitcoin <br>31zr9sgjrz45WRMbjFAzdDMDZyw3a9tnU8<br>
  Dana/Ovo/Gopay <br>087730938323

#### Contact <a href="mailto:mitsuhamizaki@gmail.com">Email</a>
  
