# ToxicMail V1.0
Generate Temporar Email Addresses From Your Terminal...

# Installation Commands :

apt update -y

apt upgrade -y

pkg install python git -y

git clone https://github.com/Toxic-Noob/ToxicMail

cd ToxicMail

pip install requests

python mail.py

# Single Installation Commands :
``` shell script
apt update -y && apt upgrade -y && pkg install python git -y && git clone https://github.com/Toxic-Noob/ToxicMail && cd ToxicMail && pip install requests && python mail.py
```

# Contact :

[*] For any Need, Contact Me :

[ Via Email ] : ToxicNoob.Sl4d3.Official@gmail.com

<br><br>
# Visitors :


![Visitor Count](https://profile-counter.glitch.me/Toxic-Noob/count.svg)

